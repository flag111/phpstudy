<?php
namespace Home\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index($name = 'hello!'){
        $this->assign('name', $name);
        $this->display();
    }
    public function hello($name='thinkphp'){
        echo 'hello,'.$name.'!';
    }
}