<?php
namespace Block\Controller;
use Think\Controller;
class IndexController extends Controller {
    public function index(){
        $this->display();
    }

    public function hello($name = 'lala') {
        echo 'hello ' . $name;
    }
}